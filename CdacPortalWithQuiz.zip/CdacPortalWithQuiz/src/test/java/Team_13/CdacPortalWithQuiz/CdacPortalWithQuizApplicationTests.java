package Team_13.CdacPortalWithQuiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CdacPortalWithQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
