package Team_13.CdacPortalWithQuiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdacPortalWithQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdacPortalWithQuizApplication.class, args);
	}

}
